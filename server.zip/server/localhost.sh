#!/bin/bash
figlet Localhost
echo -n "Enter port :- "
read port
echo -n "Entet file path :- "
read file
php -S localhost:$port -t $file 
