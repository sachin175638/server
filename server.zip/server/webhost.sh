#!/bin/bash
echo -n "Enter port :- "
read port
echo -n "Enter ip/domain :- "
read ip
echo -n "Enter file path :- "
read file
php -S $ip:$port -t $file
